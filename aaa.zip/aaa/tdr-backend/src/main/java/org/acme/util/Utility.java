package org.acme.util;

import java.sql.*;

import java.lang.reflect.Field;
import org.jboss.logging.Logger;

import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Inject;



@RequestScoped
public class Utility {
    @Inject
    Logger logger;


    public Object loadResultSetIntoObject(ResultSet rst, Object object)
            throws IllegalArgumentException, IllegalAccessException, SQLException {
        try {
            logger.info("valunn\n\n\n\n");
            Class<?> zclass = object.getClass();
            for (Field field : zclass.getDeclaredFields()) {

                try {
                    field.setAccessible(true);


                    Table column = field.getAnnotation(Table.class);
                    ResponseParam responseParam = field.getAnnotation(ResponseParam.class);
                    logger.info(field.getAnnotation(Table.class));
                    logger.info(field);
                    logger.info(column.column());
                    logger.info("awews\n\n\n\n");
                    
                 

                        // ResultSetMetaData metaData = rst.getMetaData();
                    
                        // int columnCount = metaData.getColumnCount();
                        // for (int i = 1; i <= columnCount; i++) {

                        //     logger.info(metaData.getColumnName(i));
                    
                        // }

                    // logger.info(columnCount);
                    logger.info(rst);
                    logger.info("fff");
                    logger.info("fff");
                    logger.info(rst.getObject("userID"));
                    logger.info("wwww\n\n\n\n");
                    
                    // Object value = rst.getObject(column.column());
                    Object value = rst.getObject(column.column());
                    logger.info(value);
                    
                    Class<?> type = field.getType();
                    logger.info(object);
                    logger.info("value");
                    logger.info(field);
                    // if (isPrimitive(type)) {
                    //     logger.info("asasasas\n\n\n\n");
                    //     Class<?> boxed = boxPrimitiveClass(type);

                    //     value = boxed.cast(value);
                    //     logger.info("asasasas\n\n\n\n");
                    //     logger.info(value);
                    //     logger.info("valunn\n\n\n\n");
                    // }

                    field.set(object, value);
                    logger.info(field);
                } catch (Exception e) {

                    logger.info("qqq\n\n\n\n");
                    // System.out.println("exception:::"+e);
                    continue;
                }

            }

            return object;
        } catch (Exception e) {
            //
        }

        return new Object();
    }

    public static boolean isPrimitive(Class<?> type) {
        return (type == int.class || type == long.class || type == double.class || type == float.class
                || type == boolean.class || type == byte.class || type == char.class || type == short.class);
    }

    public static Class<?> boxPrimitiveClass(Class<?> type) {
        if (type == int.class) {
            return Integer.class;
        } else if (type == long.class) {
            return Long.class;
        } else if (type == double.class) {
            return Double.class;
        } else if (type == float.class) {
            return Float.class;
        } else if (type == boolean.class) {
            return Boolean.class;
        } else if (type == byte.class) {
            return Byte.class;
        } else if (type == char.class) {
            return Character.class;
        } else if (type == short.class) {
            return Short.class;
        } else {
            String string = "class '" + type.getName() + "' is not a primitive";
            throw new IllegalArgumentException(string);
        }
    }

}
