package org.acme.dto.auth;

public class authRequestDto {

    /**
     * Data members for the Login Request
     */
    private Integer userId;
    private String userName;
    private String password;
    private Integer branchCode;


    
    /**
     * Default Constructor
     */
    public authRequestDto() {
    }

    /**
     * Constructor with all fields
     *
     * @param userId     The user's identifier.
     * @param userName   The user's name.
     * @param password   The user's password.
     * @param branchCode The branch code associated with the login.
     */
    public authRequestDto(Integer userId, String userName, String password, Integer branchCode) {
        this.userId = userId;
        this.userName = userName;
        this.password = password;
        this.branchCode = branchCode;
    }

    /**
     * Getter for userId
     *
     * @return The user's identifier.
     */
    public Integer getUserId() {
        return userId;
    }

    /**
     * Setter for userId
     *
     * @param userId The user's identifier to set.
     */
    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    /**
     * Getter for userName
     *
     * @return The user's name.
     */
    public String getUserName() {
        return userName;
    }

    /**
     * Setter for userName
     *
     * @param userName The user's name to set.
     */
    public void setUserName(String userName) {
        this.userName = userName;
    }

    /**
     * Getter for password
     *
     * @return The user's password.
     */
    public String getPassword() {
        return password;
    }

    /**
     * Setter for password
     *
     * @param password The user's password to set.
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * Getter for branchCode
     *
     * @return The branch code.
     */
    public Integer getBranchCode() {
        return branchCode;
    }

    /**
     * Setter for branchCode
     *
     * @param branchCode The branch code to set.
     */
    public void setBranchCode(Integer branchCode) {
        this.branchCode = branchCode;
    }

    /**
     * toString method for the LoginRequestDto
     *
     * @return A string representation of the object.
     */
    @Override
    public String toString() {
        return "LoginRequestDto{" +
                "userId=" + userId +
                ", userName='" + userName + '\'' +
                ", password='********'" + // Masking password for security in logs
                ", branchCode=" + branchCode +
                '}';
    }
}