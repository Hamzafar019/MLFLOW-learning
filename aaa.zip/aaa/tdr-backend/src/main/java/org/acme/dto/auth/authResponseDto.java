package org.acme.dto.auth;

import org.acme.util.ResponseParam;
import org.acme.util.Table;

public class authResponseDto {

    /**
     * Data members for the Authentication Response
     */
    @Table(column="userID")
    @ResponseParam(name="userID")
    private Integer userId;

    
    @Table(column="userName")
    @ResponseParam(name="userName")
    private String userName;


    @Table(column="password")
    @ResponseParam(name="password")
    private String password; // Consider if you really want to include this in the response

    @Table(column="branch_code")
    @ResponseParam(name="branch_code")
    private Integer branchCode;

    @Table(column="sprcNumber")
    @ResponseParam(name="sprcNumber")
    private String authToken; // Example of an authentication token
    private String errorMessage;
    private Boolean mBoolean;

    /**
     * Default Constructor
     */
    public authResponseDto() {
    }

    /**
     * Constructor with all fields
     *
     * @param userId     The user's identifier.
     * @param userName   The user's name.
     * @param password   The user's password.
     * @param branchCode The branch code associated with the login.
     * @param authToken  An authentication token (optional).
     */
    public authResponseDto(Integer userId, String userName, String password, Integer branchCode, String authToken) {
        this.userId = userId;
        this.userName = userName;
        this.branchCode = branchCode;
        this.authToken = authToken;
    }

    /**
     * Getter for userId
     *
     * @return The user's identifier.
     */
    public Integer getUserId() {
        return userId;
    }

    /**
     * Setter for userId
     *
     * @param userId The user's identifier to set.
     */
    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    /**
     * Getter for userName
     *
     * @return The user's name.
     */
    public String getUserName() {
        return userName;
    }

    /**
     * Setter for userName
     *
     * @param userName The user's name to set.
     */
    public void setUserName(String userName) {
        this.userName = userName;
    }


    /**
     * Getter for branchCode
     *
     * @return The branch code.
     */
    public Integer getBranchCode() {
        return branchCode;
    }

    /**
     * Setter for branchCode
     *
     * @param branchCode The branch code to set.
     */
    public void setBranchCode(Integer branchCode) {
        this.branchCode = branchCode;
    }

    /**
     * Getter for authToken
     *
     * @return The authentication token.
     */
    public String getAuthToken() {
        return authToken;
    }

    /**
     * Setter for authToken
     *
     * @param authToken The authentication token to set.
     */
    public void setAuthToken(String authToken) {
        this.authToken = authToken;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public Boolean getmBoolean() {
        return mBoolean;
    }

    public void setmBoolean(Boolean mBoolean) {
        this.mBoolean = mBoolean;
    }


    /**
     * toString method for the AuthResponseDto
     *
     * @return A string representation of the object.
     */
    @Override
    public String toString() {
        return "AuthResponseDto{" +
                "userId=" + userId +
                ", userName='" + userName + '\'' +
                ", branchCode=" + branchCode +
                ", authToken='" + authToken + '\'' +
                '}';
    }
}