package org.acme.service.auth;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import java.sql.*;

import org.jboss.logging.Logger;

import org.acme.dto.auth.authRequestDto;
import org.acme.dto.auth.authResponseDto;
import org.acme.querystores.auth.authQuery;
import org.acme.util.Utility;

import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Inject;
import java.util.Map;

@RequestScoped
public class authServices {
    
    @Inject
    Logger loggerObj;

    @Inject
    authQuery authQuery;


    @Inject
    Utility utilityObj;

    @Inject
    org.acme.connections.DatabaseConnector connector;

    ArrayList<Object> whereClauseList;

    
    
    public <T> List<T> authenticate(authRequestDto authRequestDto)
        throws Exception {
        
        Map<String,String> queryMapObj = null;
        authResponseDto responsedto = new authResponseDto();
        whereClauseList =new ArrayList<>();
        String whereClause="";
        whereClause+=" USER_TL.user_id = ?";
        whereClauseList.add(authRequestDto.getUserId());
        whereClause+=" AND USER_TL.user_name=?";
        whereClauseList.add(authRequestDto.getUserName());
        whereClause+=" AND USER_TL.branch_code=?";
        whereClauseList.add(authRequestDto.getBranchCode());
        
        whereClause="";
        
        queryMapObj = authQuery.findUser(whereClause, authRequestDto);
        List<authResponseDto>  responsedtoList=fnExecutePreparedQuery(authResponseDto.class,queryMapObj.get("queryString"),authRequestDto);
    
        if (responsedtoList.isEmpty()) {
            loggerObj.info("Query executed successfully but returns empty list");
            responsedto.setErrorMessage(queryMapObj.get("errorMessage"));
            responsedto.setmBoolean(true);
            responsedtoList.add(responsedto);
            return (List<T>) responsedtoList;
        }
        else {
            loggerObj.info("Query executed successfully, ");
            responsedto.setmBoolean(false);
            return (List<T>) responsedtoList;
        }

    }   
        
    
    
    
    
    public <T> List<T> fnExecutePreparedQuery(Class<T> type, String  query, authRequestDto requestDtoObj)
    throws Exception {
    Logger logger = Logger.getLogger(type, "ObjectMapper");
    List<T> list = new ArrayList<>();

    logger.info(query);
    try (
        Connection connection = connector.getConnection();
        PreparedStatement preparedStatement = connection.prepareStatement(query);)
    {

    // for (int i = 0; i < whereClauseList.size(); i++) {

    //     preparedStatement.setObject(i + 1, whereClauseList.get(i));

    //     logger.info(whereClauseList.get(i));
    // }

    logger.info("F");
    ResultSet resultSet = preparedStatement.executeQuery();
    logger.info(resultSet);

    logger.info(preparedStatement);
    logger.info("preparedStatement");
    // preparedStatement="Select * from user_tl where 1=1";
    try(ResultSet rst = preparedStatement.executeQuery()) {

        while (rst.next()) {
            T t = type.newInstance();
            utilityObj.loadResultSetIntoObject(rst, t);
            logger.info(t);
            logger.info("t");
            list.add(t);
        }
    }
    }
    return list;
    }

}   
