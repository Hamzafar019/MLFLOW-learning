package org.acme.querystores.myTable;

import org.acme.dto.MyTableDto;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.databind.ObjectMapper;
// import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.context.RequestScoped;

import com.fasterxml.jackson.databind.JsonNode;

@RequestScoped
public class MyTableQueries {

    public void updateMyTableDetailSec(String setClause, MyTableDto myTableDto) throws Exception {
        try {
            // Your DB2 JDBC or JPA code here
            // ...
        } catch (Exception e) {
            throw new Exception("Error updating myTable details: " + e.getMessage(), e);
        }
    }

    public List<MyTableDto> getMyTableDetails(MyTableDto myTableDto) throws Exception {
        try {
            // Implement your DB2 retrieval logic here.
            // ...
            return null; // Replace with your result
        } catch (Exception e) {
            throw new Exception("Error retrieving myTable details: " + e.getMessage(), e);
        }
    }

    
     public Map<String, String> myTableInsertQuery(String dtoString) { // Accept the dto as a String
        Map<String, String> queryMapObj = new HashMap<>();
        String query = "INSERT INTO MY_TABLE (id, description) VALUES (?, ?)"; // Adjust column names if needed

        queryMapObj.put("queryString", query);
        queryMapObj.put("queryError", "data not inserted");

        return queryMapObj;
    }

    public Map<String, Object> parseDtoString(String dtoString) throws IOException { // Added parsing method
        ObjectMapper objectMapper = new ObjectMapper();
        JsonNode jsonNode = objectMapper.readTree(dtoString);

        Map<String, Object> parsedData = new HashMap<>();
        parsedData.put("id", jsonNode.get("id").asInt());
        parsedData.put("description", jsonNode.get("description").asText());

        return parsedData;
    }
    // public void insertMyTableDetailSec(String myTableDto) throws Exception {
    //     try {
    //         // Implement your DB2 insertion logic here.
    //         // ...
    //     } catch (Exception e) {
    //         throw new Exception("Error inserting myTable details: " + e.getMessage(), e);
    //     }
    // }
}