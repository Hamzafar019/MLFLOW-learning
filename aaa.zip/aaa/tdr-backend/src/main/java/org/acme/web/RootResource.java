package org.acme.web;

import org.acme.dto.MyTableDto;
import org.acme.dto.auth.authRequestDto;
import org.acme.dto.auth.authResponseDto;
import org.acme.service.MyTableServices;
import org.acme.service.auth.authServices;
import org.jboss.logging.Logger;

import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

import java.util.ArrayList;
import org.acme.util.Utility;
import java.util.List;

@Path("/") // Base path for all endpoints in this resource
public class RootResource {

    @Inject
    Logger logger;

    @Inject
    MyTableServices myTableService;

    @Inject
    Utility utilityObj;

    @Inject
    authServices authServices;

    @POST
    @Path("/auth")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public   List<authResponseDto>  login(authRequestDto authRequestDto) {
        logger.info("Received login request for user: " + authRequestDto.getUserId() +
                    " from branch: " + authRequestDto.getBranchCode());
        
        try {
            
            logger.info("Successfully retrieved aaa data: \n\n\n\n\nSHIT!!!!!!!!");
            return authServices.authenticate(authRequestDto);
            // String responseMessage = "Login request processed (authentication not fully implemented). " +
            //                          "Received userId: " + authRequestDto.getUserId() +
            //                          ", branchCode: " + authRequestDto.getBranchCode();
            // return Response.ok(responseMessage).build();


        } catch (Exception e) {
             logger.info("Request on Insert Eprc Transaction Details Exception Block ");
            e.printStackTrace();
            List<authResponseDto> authResponseDtolist = new ArrayList<>();
            authResponseDto dtos = new authResponseDto();
            dtos.setmBoolean(true);
            dtos.setErrorMessage("Error");
            authResponseDtolist.add(dtos);
            return authResponseDtolist;
        }
    }

    @GET
    @Path("/mytable")
    @Produces(MediaType.APPLICATION_JSON) // Changed to APPLICATION_JSON for consistency with POST
    public Response getMyTableData(MyTableDto myTableDto) {
        try {
            List<MyTableDto> data = myTableService.getMyTableDetails(myTableDto);
            return Response.ok(data).build();
        } catch (Exception e) {
            logger.error("Error getting myTable data: " + e.getMessage(), e);
            return Response.serverError().entity(e.getMessage()).build();
        }
    }

    @PUT
    @Path("/mytable")
    @Consumes(MediaType.APPLICATION_JSON) // Changed to APPLICATION_JSON for consistency
    @Produces(MediaType.APPLICATION_JSON) // Changed to APPLICATION_JSON for consistency
    public Response updateMyTableData(@QueryParam("setClause") String setClause, MyTableDto myTableDto) {
        try {
            myTableService.updateMyTableDetails(setClause, myTableDto);
            return Response.ok().build();
        } catch (Exception e) {
            logger.error("Error updating myTable data: " + e.getMessage(), e);
            return Response.serverError().entity(e.getMessage()).build();
        }
    }

    @POST
    @Path("/mytable")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response insertMyTableData(String data) {
        logger.info("Received insert request for myTable data: " + data);
        try {
            myTableService.insertMyTableDetails(data);
            return Response.ok().build();
        } catch (Exception e) {
            logger.error("Error inserting myTable data: " + e.getMessage(), e);
            return Response.serverError().entity(e.getMessage()).build();
        }
    }
}