package org.acme.querystores.auth;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.jboss.logging.Logger;

import org.acme.dto.auth.authRequestDto;

import jakarta.enterprise.context.RequestScoped;

@RequestScoped
public class authQuery {
 
    public Map<String, String> findUser(String whereClause, authRequestDto authRequestDto) {
        Map<String, String> queryMapObj = new HashMap<>();
        String query = "SELECT * FROM user_tl";
        queryMapObj.put("queryString", query);
        queryMapObj.put("queryError", "userId = " + authRequestDto);
        return queryMapObj;
    }
    public Map<String, String> findUserByUsernameQuery(authRequestDto authRequestDto) {
        Map<String, String> queryMapObj = new HashMap<>();
        String query = "SELECT user_id, user_name, password, branch_code FROM users WHERE user_name = ?";
        queryMapObj.put("queryString", query);
        queryMapObj.put("queryError", "userName = " + authRequestDto.getUserId());
        return queryMapObj;
    }




   

}
