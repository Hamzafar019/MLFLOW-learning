package org.acme.service;

import org.acme.dto.MyTableDto;
import org.acme.querystores.myTable.MyTableQueries;
import org.jboss.logging.Logger;

import jakarta.inject.Inject;
import jakarta.enterprise.context.ApplicationScoped;

import java.io.IOException;
import java.sql.PreparedStatement;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.sql.Connection;

@ApplicationScoped
public class MyTableServices {


    @Inject
    Logger loggerObj;

    @Inject
    org.acme.connections.DatabaseConnector connector;

    @Inject
    MyTableQueries myTableQueryStore;

    public List<MyTableDto> getMyTableDetails(MyTableDto myTableDto) throws Exception {
        loggerObj.info("Request on myTable dataaccess with request dto as : " + myTableDto);
        return myTableQueryStore.getMyTableDetails(myTableDto);
    }

    public void updateMyTableDetails(String setClause, MyTableDto myTableDto) throws Exception {
        loggerObj.info("Update request on myTable dataaccess with setClause: " + setClause + " and dto: " + myTableDto);
        myTableQueryStore.updateMyTableDetailSec(setClause, myTableDto);
    }


    public void insertMyTableDetails(String dtoString) throws Exception { // Accept the DTO as a String
            loggerObj.info("Insert request on myTable dataaccess with dto: " + dtoString);
            Map<String, String> queryMap = myTableQueryStore.myTableInsertQuery(dtoString);
            String query = queryMap.get("queryString");

            try {
                Map<String, Object> parsedData = myTableQueryStore.parseDtoString(dtoString); // Parse the DTO String

                try (Connection connection = connector.getConnection();
                    PreparedStatement preparedStatement = connection.prepareStatement(query)) {

                    preparedStatement.setInt(1, (Integer) parsedData.get("id")); // Set parameters from parsed data
                    preparedStatement.setString(2, (String) parsedData.get("description"));

                    preparedStatement.executeUpdate();
                }
            } catch (Exception e) {
                loggerObj.error("Error inserting data: " + e.getMessage(), e);
                throw new Exception("Database insertion failed", e);
            }
        }


    // public void insertMyTableDetails(String myTableDto) throws Exception {
    //     loggerObj.info("Insert request on myTable dataaccess with dto: " + myTableDto);
    //     myTableQueryStore.insertMyTableDetailSec(myTableDto);

    // }
}