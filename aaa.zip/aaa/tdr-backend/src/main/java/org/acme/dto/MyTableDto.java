package org.acme.dto;

public class MyTableDto {
    public int id;
    public int description;

    public MyTableDto() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getDescription() {
        return description;
    }

    public void setDescription(int description) {
        this.description = description;
    }
}