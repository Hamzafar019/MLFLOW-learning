package org.acme.util;

/**
 * Imported Classes, Interfaces and their use 
 * package com.teresol.dataaccess.ms.dataaccess_ms_accountIBANdetail.util     Main package of the class
 * java.lang.annotation.Retention;                                            Retention to determine at which point an annotation is discarded
 * java.lang.annotation.RetentionPolicy;                                      RetentionPolicy to determine at which point an annotation is discarded
 */

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;


/**
 * ResponseParam is a functional interface to create custom annotation.
 * Interface Names: ResponseParam.java
 * @version 1.0
 * @brief Functional interface to create custom annotation ResponseParam
 */

 
@Retention(RetentionPolicy.RUNTIME)
public @interface ResponseParam {
    public String name();
}