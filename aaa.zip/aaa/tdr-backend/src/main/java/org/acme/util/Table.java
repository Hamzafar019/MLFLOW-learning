package org.acme.util;
/**
 * Imported Classes, Interfaces and their use
 * java.lang.annotation.Retention;            RetentionPolicy to determine at which point an annotation is discarded
 * java.lang.annotation.RetentionPolicy;      RetentionPolicy to determine at which point an annotation is discarded
 */

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * Table is a functional interface to create custom annotation.
 * Interface Names: Table.java
 * @version 1.0
 * @brief Functional interface to create custom annotation Table
*/

@Retention(RetentionPolicy.RUNTIME)
public @interface Table {
    public String name() default "";
    public String column() default "";
}